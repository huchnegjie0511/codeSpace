//应用
//page（）页面

App({
  globalData:{
    // user:{
    //   name:'hu',
    //   favor:['漫画','小说']
    // }
  }
})
//配置
Page({
  //页面的数据
  data:{
    user:{}
  },
  onLaunch(){
    //console.log('应用启动了')
    wx.request({
      url: 'https://resources.ninghao.net/wxapp-case/db.json',
      success:(response)=>{
        //console.log(response);
        Object.assign(this.globalData,
          response.data)
          console.log(this,'-----')
      }
    })
  },
})
