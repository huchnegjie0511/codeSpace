const Router = require('@koa/router');
const router = new Router();
const jwt = require('jsonwebtoken');
const jwtAuth = require('koa-jwt');
const { userServices, userLogin } = require('../controllers/mysqlControl.js');

const secret = 'jwt demo';
//定义接口
router.post('/Login',async(ctx)=>{
    const {username,password} = ctx.request.body;
    try{
        const result=await userLogin(username,password)
        if(result.length){
            const username=result[0].username; 
            ctx.body={
                code:200,
                user:username,
                message:'登录成功',
                token:jwt.sign({
                    data:username,
                    exp:Math.floor(Date.now()/1000)+60*60
                },secret)
            }
        }else{
            ctx.body={
                code:404,
                data:'error',
                message:'账号或者密码不正确'
            }
        }
    }catch(err){
        ctx.body={
            code:500,
            data:err,
            message:'服务器异常'
        }
    }
})
router.get(
    "/Login",
    jwtAuth({
      secret
    }),
    async ctx => {
      // 验证通过，state.user
      console.log(ctx.state.user);
      ctx.body = {
        message: "获取数据成功",
        userinfo: ctx.state.user.data 
      };
    }
  )

module.exports = router;
