const config={
    database:{
        DATABASE:'shop',
        USERNAME:'root',
        PASSWORD:'password',
        PORT:'3306',
        HOST:'localhost'
    }
}

module.exports = config;