<template>
  <div>
    <router-view></router-view>
    <!-- 路由路口 -->
  </div>
</template>

<script >
export default{

}
</script>

<style lang="css" scoped>

</style>