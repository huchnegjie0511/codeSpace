import axios from 'axios';
import { showSuccessToast, showFailToast } from 'vant';






axios.defaults.baseURL = 'http://localhost:3000/api';
axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8';

//请求拦截
axios.interceptors.request.use(config=>{
    const token = localStorage.getItem('token');
    if(token){
        //将token放到请求头发送给服务器,将tokenkey放在请求头中
        config.headers.common['Authorization'] = token;
    }
    return config;//如果找到了令牌，它将该令牌添加到请求头的 'Authorization' 字段中，以便将令牌发送给服务器进行验证。
})

//响应拦截
axios.interceptors.response.use(res=>{
    if(res.status !== 200){//程序错误
        showFailToast('服务器异常')
    }
    else{
        if(res.data.code !==404){
            showFailToast(res.data.message)
            return Promise.reject(res)
        }
    }
}
    
)

export default axios;