使用amfe-flexible进行字体适配
常见标签样式初始化 reset.css



组件开发步骤
首先创建views文件夹 创建你需要的组件
下载vue-router的包  
创建router文件夹，创建index.js文件导入包和导出路由（export）
在main.js中use路由
在app.vue中放置router入口（router-views）
在页面中写上响应的页面地址


sever创建 
npm init -y


下载koa
npm i  koa
npm i  koa/router
npm i koa-bodyparser 



# server
1. navicat 连接mysql
2. 创建一个 库
3. 运行

4. 配置router 接口 routers
5. 创建mySql连接

6. 引入mysql库


# client
1. 移动端适配 npm add amfe-flex-flexible
2. 标签样式初始化
3. vant UI
4. axios 封装